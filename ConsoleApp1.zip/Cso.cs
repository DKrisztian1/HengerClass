﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    public class Cso : Henger
    {
        double falVastagsag;

        public Cso(double sugar, double magassag) : base(sugar, magassag)
        {
            this.magassag = magassag;
            this.sugar = sugar;
            falVastagsag = 1;
        }

        public Cso(double sugar, double magassag, double falVastagsag) : base(sugar, magassag)
        {
            this.magassag = magassag;
            this.sugar = sugar;
            this.falVastagsag = falVastagsag;
        }
        //a


        public double FalVastagsag { get => falVastagsag; }

        public override double Terfogat()
        {
            double belsoAtmero = sugar*2 - falVastagsag*2;
            return Math.Round((belsoAtmero / 2)* (belsoAtmero / 2) *Math.PI * magassag, 2);
        }


        public override string ToString()
        {
            return $"térfogat:{Terfogat()}; sugár:{sugar}; magasság:{magassag}; falvastagság:{falVastagsag}";
        }
    }
}